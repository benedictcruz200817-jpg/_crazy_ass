# WakePlus Alarm + Subscription Demo

Open `index.html` in a modern browser.

## What it does
- Lets a user choose an alarm time.
- Plays a repeating browser-generated beep when the time is reached.
- Plays a stronger multi-tone repeating alert when the alarm rings.
- Opens an optional subscription offer when the alarm rings.
- Includes Dismiss and 5-minute Snooze controls.
- Includes a "Test now" button.

## Connect payments
Inside `index.html`, find the `subscribeBtn` click handler and replace the demo `alert(...)` with your hosted checkout URL, for example a Stripe Payment Link:

```js
window.location.href = 'https://buy.stripe.com/YOUR_PAYMENT_LINK';
```

For a production subscription app, you should also add a backend/webhook to verify payment status instead of trusting only the browser.

## Browser note
Browsers often require a user interaction before audio can play and may throttle timers in background tabs.


## Publish it on the web

### Option 1: Netlify Drop
1. Go to Netlify Drop.
2. Drag the `alarm_subscription_website` folder onto the page.
3. Netlify gives you a public `*.netlify.app` URL.
4. You can later attach your own domain.

### Option 2: GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `README.md`.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**.
5. Select your main branch and `/root`.
6. GitHub will give you a public website URL.

### Option 3: Vercel
1. Create a new Vercel project.
2. Import a GitHub repository containing this site.
3. Deploy it.
4. Add your own domain in the project settings if desired.

For payments, use a real hosted checkout provider and verify subscriptions on a backend before unlocking paid features.
